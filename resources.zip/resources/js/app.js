import './bootstrap';

import Alpine from 'alpinejs';
import ApexCharts from 'apexcharts';

window.ApexCharts = ApexCharts;
window.Alpine = Alpine;
ApexCharts.start();
Alpine.start();
