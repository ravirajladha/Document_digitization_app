<x-app-layout>
 

    <x-header/>
    @include('layouts.sidebar')

<div class="content-body default-height">
    <!-- row -->
    <div class="container-fluid">


<div class="page-body">
    <div class="container-fluid">
        <div class="page-title">
            <div class="row">

            </div>
        </div>
    </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="form theme-form projectcreate">
                        <div class="row">
                            <h3>Welcome Reviewer!! Add Documents.</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


</div>
</div>

@include('layouts.footer')


</x-app-layout>

