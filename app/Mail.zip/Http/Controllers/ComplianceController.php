<?php

namespace App\Http\Controllers;
use App\Models\{Receiver, Receiver_type, Master_doc_type, Master_doc_data, Table_metadata, Document_assignment,Compliance};
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Exception;
use Illuminate\Http\Request;

class ComplianceController extends Controller
{
    public function showCompliances()
    {
        $compliances = Compliance::with([ 'documentType', 'document'])->orderBy('created_at', 'desc')
            ->get();

        $documentTypes = Master_doc_type::all();
        

        return view('pages.compliances', [
            'compliances' => $compliances,
            'documentTypes' => $documentTypes,
       
        ]);
    }

    public function store(Request $request)
    {
  
        try {
            $validatedData = $request->validate([
                'document_type' => 'required|exists:master_doc_types,id',
                'document_id' => 'required|exists:master_doc_datas,id',
                'name' => 'required|string|max:255',
                'due_date' => 'required|date',
                'is_recurring' => 'sometimes|boolean'
            ]);
    
            $compliance = new Compliance();
            $compliance->document_type = $validatedData['document_type'];
            $compliance->doc_id = $validatedData['document_id'];
            $compliance->name = $validatedData['name'];
            $compliance->due_date = $validatedData['due_date'];
            $compliance->is_recurring = $request->has('is_recurring') ? 1 : 0;
        
            $compliance->created_by = Auth::user()->id;
            $compliance->save();
    
            session()->flash('toastr', ['type' => 'success', 'message' => 'Compliance created successfully.']);
        } catch (Exception $e) {
            // Log the error for debugging
            logger()->error('Error in creating compliance: ' . $e->getMessage());
    
            // Flash error message to session
            session()->flash('toastr', ['type' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
        }
    
        return back();
    }

}
